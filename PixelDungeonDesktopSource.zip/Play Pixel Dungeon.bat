@echo off
setlocal
cd /d "%~dp0"
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot"
if not exist "%JAVA_HOME%\bin\javac.exe" (
  echo A Java Development Kit was not found at the expected location.
  echo Install a JDK 17 or newer, then edit this launcher if needed.
  pause
  exit /b 1
)
"%JAVA_HOME%\bin\javac.exe" PixelDungeonDesktop.java
if errorlevel 1 (
  echo The game did not compile. Please check the Java installation.
  pause
  exit /b 1
)
"%JAVA_HOME%\bin\javaw.exe" PixelDungeonDesktop
endlocal
