# Pixel Dungeon Desktop Remake

A small offline Windows desktop adaptation inspired by the original *Pixel Dungeon*, using artwork from the original project. The launcher compiles the Java source with a local JDK and opens the game in its own window.

## Play

1. Install a Java Development Kit (JDK 17 or newer).
2. Double-click desktop/Play Pixel Dungeon.bat.

The launcher currently points to the JDK location on the author's Windows computer. If your JDK is installed elsewhere, edit the JAVA_HOME line in the batch file.

## Controls

- Arrow keys or WASD: move
- G: pick up an item
- E: eat food
- P: drink a healing potion
- I: open inventory
- Ctrl+S or Esc: save
- L: load a saved game from the title screen
- 1–4: choose Warrior, Mage, Rogue, or Huntress

Save data is stored in .pixel-dungeon-desktop.save in the user's home folder.

## About this remake

This is a compact, independent desktop adaptation. It is not the complete original Android game or a direct port of its full codebase. The game source in desktop/ is modified/new work, while the pixel-dungeon/ and PD-classes/ folders preserve the official upstream source and assets for reference and attribution.

The original game is by Oleg Dolya (Watabou). Its source and included artwork are provided under the GNU General Public License, version 3 or (at your option) any later version. The upstream projects and their notices are included in this repository. See LICENSE.txt, pixel-dungeon/, and PD-classes/ for the license and original copyright headers.

This repository's adaptation is also offered under GPL-3.0-or-later. Changes to the desktop adaptation are marked as such in its source.

Upstream projects:

- [Pixel Dungeon](https://github.com/watabou/pixel-dungeon)
- [PD-classes](https://github.com/watabou/PD-classes)
