Original Pixel Dungeon source

This folder contains source code and assets from the official Pixel Dungeon
repository and its companion PD-classes library:

  https://github.com/watabou/pixel-dungeon
  https://github.com/watabou/PD-classes

Both repositories include LICENSE.txt (GNU General Public License, version 3).
Keep that license and the original notices with the source.

This is the original Android source project, not a ready-to-run Windows desktop
app. Its README says it requires the companion library. Building/running it
requires an Android-compatible Java development environment. No Java runtime
was available in the current computer session, so this source has not been
built or launched here.

The earlier PocketDepths.py remains a separate original prototype. It is not
the original Pixel Dungeon game.
