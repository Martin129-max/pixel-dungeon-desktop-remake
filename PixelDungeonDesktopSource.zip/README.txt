PIXEL DUNGEON — DESKTOP EDITION

Double-click “Play Pixel Dungeon.bat” to compile and start the offline game.
The launcher uses the Java Development Kit installed on this computer.
The original assets are loaded from the sibling pixel-dungeon/assets folder.

Controls
  Arrow keys or WASD  Move one turn
  G                  Pick up an item
  E                  Eat food
  P                  Drink a healing potion
  I                  Open inventory
  Ctrl+S or Esc      Save the run
  L                  Load a saved run from the title screen
  Enter              Choose Warrior / restart after defeat
  1–4                Choose Warrior, Mage, Rogue, or Huntress

The save is stored in your Windows user folder as .pixel-dungeon-desktop.save.
This desktop adaptation is a compact playable remake using original Pixel
Dungeon artwork; it is not the full original Android game or a full source
port. It includes four hero choices, generated floors, fog of war, monsters,
turn-based combat, food, potions, XP, leveling, and local saving.

The original project's source, companion library, and artwork are in the
neighboring pixel-dungeon and PD-classes folders. They are licensed under the
GNU General Public License version 3 (or later). See LICENSE.txt in both
source folders for the full terms and notices.
